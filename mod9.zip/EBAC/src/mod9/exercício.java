package mod9;

public class exercício {
	public static void main(String[] args) {
		
		long cpf = 45632187954l ; 
		Long cpf1 = cpf ; 
		
		System.out.println(cpf1); 
		

	}


}

